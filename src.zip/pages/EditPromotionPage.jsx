import React from 'react'

const EditPromotion = () => {
  return (
    <div >EditPromotion</div>
  )
}

export default EditPromotion