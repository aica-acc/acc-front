import React from 'react'

const EditPrompt = () => {
  return (
    <div>EditPrompt</div>
  )
}

export default EditPrompt