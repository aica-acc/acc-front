import React from 'react'

const CreateVideoPromptPage = () => {
  return (
    <div>CreateVideoPromptPage</div>
  )
}

export default CreateVideoPromptPage