import React from 'react'

const CreateCardnewsPromptPage = () => {
  return (
    <div>CreateCardnewsPromptPage</div>
  )
}

export default CreateCardnewsPromptPage