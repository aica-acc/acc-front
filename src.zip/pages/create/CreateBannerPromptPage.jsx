import React from 'react'

const CreateBannerPromptPage = () => {
  return (  
    <div>CreateBannerPromptPage</div>
  ) 
}

export default CreateBannerPromptPage   