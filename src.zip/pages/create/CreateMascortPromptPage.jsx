import React from 'react'

const CreateMascortPromptPage = () => {
  return (
    <div>CreateMascortPromptPage</div>
  )
}

export default CreateMascortPromptPage