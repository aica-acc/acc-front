import React from 'react'

const CreateleafletPromptPage = () => {
  return (
    <div>CreateleafletPromptPage</div>
  )
}

export default CreateleafletPromptPage