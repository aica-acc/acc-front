import React from 'react'

const AnalyzePosterTrendPage = () => {
  return (
    <div>AnalyzePosterTrendPage</div>
  )
}

export default AnalyzePosterTrendPage