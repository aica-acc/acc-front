import React from 'react'

const AnalyzeCardnewsTrendPage = () => {
  return (
    <div>AnalyzeCardnewsTrendPage</div>
  )
}

export default AnalyzeCardnewsTrendPage