import React from 'react'

const AnalyzeMascortTrendPage = () => {
  return (
    <div>AnalyzeMascortTrendPage</div>
  )
}

export default AnalyzeMascortTrendPage