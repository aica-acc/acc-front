import React from 'react'

const AnalyzeLeafletTrendPage = () => {
  return (
    <div>AnalyzeLeafletTrendPage</div>
  )
}

export default AnalyzeLeafletTrendPage