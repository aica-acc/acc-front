import React from 'react'

const AnalyzeVideoTrendPage = () => {
  return (
    <div>CreateVideoPromptPage</div>
  )
}

export default AnalyzeVideoTrendPage