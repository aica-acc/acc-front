import React from 'react'

const AnalyzeReportPage = () => {
  return (
    <div>AnalyzeReportPage</div>
  )
}

export default AnalyzeReportPage