import React from 'react'

const AnalyzeBannerTrendPage = () => {
  return (
    <div className='flex justify-center'>AnalyzeBannerTrendPage</div>
  )
}

export default AnalyzeBannerTrendPage