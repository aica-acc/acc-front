
import Approuter from "./utils/routes";
import './App.css'
import MainLayout from "./layout/MainLayout";


function App() {
  

  return (
      <>
      <Approuter />
      </>
  )
}

export default App
